var express = require('express');
var router = express.Router();

router.post("/", function (req, res, next) {

    console.log("aaaa");
    var x = req.body.x
    var y= req.body.y;
    var z= req.body.z;
    var l= req.body.l;

    console.log(x);


    res.json(
        {"Hi": "OK",
            "x":x,
            "y":y,
            "z":z,
            "l":l
        });

});

module.exports = router;