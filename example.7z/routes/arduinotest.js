var express = require('express');
var router = express.Router();

router.get('/', function (req, res, next) {
    res.render('testing', { title: 'testing' });
    console.log('connected');
});

router.get('/:switch', function (req, res, next) {
    var onoff = req.params.switch;
    if (onoff == 'on') setLED(1);
    if (onoff == 'off') setLED(0);
    res.render('testing', { title: 'testing : ' + req.params.switch });
    console.log('received from web');
});

module.exports = router;

function setLED(flag) {
    var fs = require('fs');
    fs.open('/dev/ttyUSB0', 'a', 666, function (err, fd) {
        if (err)
        {
            console.error(err);
            return;
        }
        fs.write(fd, flag ? '1' : '0', null, null, null, function (err) {
            if (err)
            {
                console.error(err);
                return;
            }
            fs.close(fd, function () {
                console.log('to ard');
            });
        })
    })
}